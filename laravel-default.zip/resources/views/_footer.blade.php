<div class="bg-white text-left px-10">
    2021 JCQ Production
    <a class="text-blue-600 px-2 hover:text-blue-300" href="/faq">faq</a>
    |
    <a class="text-blue-600 px-2 hover:text-blue-300" href="/about">about</a>
    |
    <a class="text-blue-600 px-2 hover:text-blue-300" href="/contact">contact</a>
    |
</div>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="/games/<?php echo e($game->id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('_scenario_select', ['scenario'=>$game->scenario], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class= "px-6 py-3 m-2 border-8 border-gray-300">
            <div class="">
                <label class="flex-1 block mb-2 text-xs font-bold tracking-wide text-indigo-400 uppercase" for="grid-first-name">
                Description of Game
                </label>
                <textarea class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none" name='description' rows="4"><?php echo e($game->description); ?></textarea>
            </div>
        </div>
        <div class='px-6 py-3 m-2 border-8 border-gray-300'>
            <div class="flex-1 block mb-2 text-xs font-bold tracking-wide text-indigo-400 uppercase"> Player 1 Information</div>
            <textarea class="py-0 text-center" name="player1_name" id="player1_name"><?php echo e($game->player1_name); ?></textarea>
            <textarea class="py-0 text-center" name="player1_army" id="player1_army"><?php echo e($game->player1_army); ?></textarea>
            <textarea class="py-0 text-center" name="player1_primary" id="player1_primary"><?php echo e($game->player1_primary); ?></textarea>
            <textarea class="py-0 text-center" name="player1_secondary" id="player1_secondary"><?php echo e($game->player1_secondary); ?></textarea>

        </div>
        <div class='px-6 py-3 m-2 border-8 border-gray-300'>
            <div class="flex-1 block mb-2 text-xs font-bold tracking-wide text-indigo-400 uppercase"> Player 2 Information</div>
            <textarea class="py-0 text-center" name="player2_name" id="player2_name"><?php echo e($game->player2_name); ?></textarea>
            <textarea class="py-0 text-center" name="player2_army" id="player2_army"><?php echo e($game->player2_army); ?></textarea>
            <textarea class="py-0 text-center" name="player2_primary" id="player2_primary"><?php echo e($game->player2_primary); ?></textarea>
            <textarea class="py-0 text-center" name="player2_secondary" id="player2_secondary"><?php echo e($game->player2_secondary); ?></textarea>

        </div>
        <div class="control">
            <button class="flex-1 px-4 py-2 m-2 font-bold text-white bg-blue-500 rounded-full button is-link mr-l hover:bg-blue-700" type="submit">Submit</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/ScoreTracker/resources/views/edit.blade.php ENDPATH**/ ?>
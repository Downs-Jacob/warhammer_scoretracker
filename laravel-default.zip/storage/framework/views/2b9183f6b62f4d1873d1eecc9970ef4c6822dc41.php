<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
<div class="text-green-500 mt-2">
    <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
<div class="flex bg-gray-200">

    <div class="flex-1 text-gray-700 text-center bg-gray-400 px-4 py-2 m-2">
        <h1 class="font-bold">Game Id: <?php echo e($game->id); ?></h1>
        <br>
        Date : <?php echo e($game->created_at); ?>

        <br>
        Scenario: <?php echo e($game->scenario); ?>

    </div>
    <div class="flex-1 text-gray-700 text-center bg-gray-400 px-4 py-2 m-2">
        Player 1 Name: <?php echo e($game->player1_name); ?>

        <br>
        Player 1 Army: <?php echo e($game->player1_army); ?>

        <br>
        Player 1 Primary Score: <?php echo e($game->player1_primary); ?>

        <br>
        Player 1 Secondary Score: <?php echo e($game->player1_secondary); ?>

        <br>
        Player 1 Score: <?php echo e($game->player1_score); ?>

    </div>
    <div class="flex-1 text-gray-700 text-center bg-gray-400 px-4 py-2 m-2">
        Player 2 Name: <?php echo e($game->player2_name); ?>

        <br>
        Player 2 Army: <?php echo e($game->player2_army); ?>

        <br>
        Player 2 Primary Score: <?php echo e($game->player2_primary); ?>

        <br>
        Player 2 Secondary Score: <?php echo e($game->player2_secondary); ?>

        <br>
        Player 2 Score: <?php echo e($game->player2_score); ?>

    </div>
</div>
    <div class="flex-1 text-gray-700 text-center bg-gray-400 px-4 py-2 m-2">
        Description: <?php echo e($game->description); ?>

    </div>
<div class="py-4">
    <a href="<?php echo e(route('archive')); ?>" class="flex-1 px-4 py-2 m-2 font-bold text-white bg-blue-500 rounded-full mr-l hover:bg-blue-700">
        Return to Archive
    </a>
    <a href="<?php echo e(route('edit', ['game' => $game])); ?>" class="flex-1 px-4 py-2 m-2 font-bold text-white bg-blue-500 rounded-full mr-l hover:bg-blue-700">
        Edit Game
    </a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\ScoreTracker\resources\views//show.blade.php ENDPATH**/ ?>
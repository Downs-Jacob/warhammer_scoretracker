<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
<div class="mt-2 text-green-500">
    <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
<div class="flex bg-blue-200 py-2 px-4">

    <div class="flex-1 px-4 py-2 m-2 text-center text-gray-700 bg-blue-100 rounded-xl">
        <h1 class="font-bold">Game Id: <?php echo e($game->id); ?></h1>
        Date : <?php echo e($game->created_at); ?>

        <br>
        Scenario: <?php echo e($game->scenario); ?>

        <br>

        <?php if($game->player1_primary + $game->player1_secondary > $game->player2_primary + $game->player2_secondary): ?>
            Player 1 Victory
        <?php elseif($game->player1_primary + $game->player1_secondary === $game->player2_primary + $game->player2_secondary): ?>
            The Game was a Tie
        <?php else: ?>
            Player 2 Victory
        <?php endif; ?>

    </div>
    <div class="flex-1 px-4 py-2 m-2 text-center text-gray-700 bg-blue-100 rounded-xl">
        Player 1 Name: <?php echo e($game->player1_name); ?>

        <br>
        Player 1 Army: <?php echo e($game->player1_army); ?>

        <br>
        Player 1 Primary Score: <?php echo e($game->player1_primary); ?>

        <br>
        Player 1 Secondary Score: <?php echo e($game->player1_secondary); ?>

        <br>
        Player 1 Total Score: <?php echo e($game->player1_primary + $game->player1_secondary); ?>

    </div>
    <div class="flex-1 px-4 py-2 m-2 text-center text-gray-700 bg-blue-100 rounded-xl">
        Player 2 Name: <?php echo e($game->player2_name); ?>

        <br>
        Player 2 Army: <?php echo e($game->player2_army); ?>

        <br>
        Player 2 Primary Score: <?php echo e($game->player2_primary); ?>

        <br>
        Player 2 Secondary Score: <?php echo e($game->player2_secondary); ?>

        <br>
        Player 2 Total Score: <?php echo e($game->player2_primary + $game->player2_secondary); ?>

    </div>
</div>
<div class="flex px-4 pb-2 bg-blue-200 shadow-xl">
    <div class="flex-1 px-4 py-2 m-2 text-center text-gray-700 bg-blue-100 rounded-xl">
        Description: <?php echo e($game->description); ?>

    </div>
</div>
<div class="pt-12 py-4">
    <a href="<?php echo e(route('archive')); ?>" class="flex-1 px-4 py-2 m-2 font-bold text-white bg-blue-500 rounded-full mr-l hover:bg-blue-700">
        Return to Archive
    </a>
    <a href="<?php echo e(route('edit', ['game' => $game])); ?>" class="flex-1 px-4 py-2 m-2 font-bold text-white bg-blue-500 rounded-full mr-l hover:bg-blue-700">
        Edit Game
    </a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/ScoreTracker/resources/views//show.blade.php ENDPATH**/ ?>
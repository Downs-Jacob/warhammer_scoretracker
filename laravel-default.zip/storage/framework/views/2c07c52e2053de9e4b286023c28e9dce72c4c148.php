    <?php $__env->startSection('content'); ?>
        <div class="container flex justify-center mx-auto">
            <div class="shadow-xl px-12 py-8 bg-gray-200 border border-gray-300 rounded-xl">
                <div class="col-md-8">

                    <div class="mb-4 text-lg font-bold"><?php echo e(__('Login')); ?></div>


                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class='mb-6'>
                            <label class="block mb-2 text-xs font-bold uppercase text-gray-700" for="email">
                                Email
                            </label>
                            <input class="w-full p-2 border border-gray-400" type="text" name="email" id="email"
                                autocomplete="email" value="<?php echo e(old('email')); ?>" required>

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class='mb-6'>
                            <label class="block mb-2 text-xs font-bold uppercase text-grey-700" for="password">
                                Password
                            </label>
                            <input class="w-full p-2 border border-gray-400" type="password" name="password" id="password"
                                autocomplete="current-password" required>

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class='mb-6'>
                            <div>
                                <input class="mr-1" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label class='text-xs font-bold text-gray-700 uppercase' for="remember"> Remember Me </label>
                            </div>


                            <?php $__errorArgs = ['remember'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <button type="submit" class="px-4 py-2 mr-2 text-white bg-blue-400 rounded hover:bg-blue-500">
                                Submit
                            </button>

                            <a href="<?php echo e(route('password.request')); ?>"> Forgot Your Password </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/ScoreTracker/resources/views/auth/login.blade.php ENDPATH**/ ?>
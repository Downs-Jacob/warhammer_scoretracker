<?php $__env->startSection('content'); ?>
    <form>
        <?php echo $__env->make('_scenario_select', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <textarea class="textarea" name="player1_name" id="player1_name"><?php echo e($game->player1_name); ?></textarea>
            <textarea class="textarea" name="player1_army" id="player1_army"><?php echo e($game->player1_army); ?></textarea>
            <textarea class="textarea" name="player1_primary" id="player1_primary"><?php echo e($game->player1_primary); ?></textarea>
            <textarea class="textarea" name="player1_secondary" id="player1_secondary"><?php echo e($game->player1_secondary); ?></textarea>
            <textarea class="textarea" name="player1_score" id="player1_score"><?php echo e($game->player1_score); ?></textarea>
        </div>
        <div>
            <textarea class="textarea" name="player2_name" id="player2_name"><?php echo e($game->player2_name); ?></textarea>
            <textarea class="textarea" name="player2_army" id="player2_army"><?php echo e($game->player2_army); ?></textarea>
            <textarea class="textarea" name="player2_primary" id="player2_primary"><?php echo e($game->player2_primary); ?></textarea>
            <textarea class="textarea" name="player2_secondary" id="player2_secondary"><?php echo e($game->player2_secondary); ?></textarea>
            <textarea class="textarea" name="player2_score" id="player2_score"><?php echo e($game->player2_score); ?></textarea>

        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\ScoreTracker\resources\views//edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <form method="POST" action="/games/<?php echo e($game->id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('_scenario_select', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class= "border-8 border-gray-300 py-3 px-6 m-2">
            <div class="">
                <label class="flex-1 block mb-2 text-xs font-bold tracking-wide text-indigo-400 uppercase" for="grid-first-name">
                Description of Game
                </label>
                <textarea class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none" name='description' rows="4"><?php echo e($game->description); ?></textarea>
            </div>
        </div>
        <div class='border-8 border-gray-300 py-3 px-6 m-2'>
            <div class="flex-1 block mb-2 text-xs font-bold tracking-wide text-indigo-400 uppercase"> Player 1 Information</div>
            <textarea class="text-center py-0" name="player1_name" id="player1_name"><?php echo e($game->player1_name); ?></textarea>
            <textarea class="text-center py-0" name="player1_army" id="player1_army"><?php echo e($game->player1_army); ?></textarea>
            <textarea class="text-center py-0" name="player1_primary" id="player1_primary"><?php echo e($game->player1_primary); ?></textarea>
            <textarea class="text-center py-0" name="player1_secondary" id="player1_secondary"><?php echo e($game->player1_secondary); ?></textarea>
            <textarea class="text-center py-0" name="player1_score" id="player1_score"><?php echo e($game->player1_score); ?></textarea>
        </div>
        <div class='border-8 border-gray-300 py-3 px-6 m-2'>
            <div class="flex-1 block mb-2 text-xs font-bold tracking-wide text-indigo-400 uppercase"> Player 2 Information</div>
            <textarea class="text-center py-0" name="player2_name" id="player2_name"><?php echo e($game->player2_name); ?></textarea>
            <textarea class="text-center py-0" name="player2_army" id="player2_army"><?php echo e($game->player2_army); ?></textarea>
            <textarea class="text-center py-0" name="player2_primary" id="player2_primary"><?php echo e($game->player2_primary); ?></textarea>
            <textarea class="text-center py-0" name="player2_secondary" id="player2_secondary"><?php echo e($game->player2_secondary); ?></textarea>
            <textarea class="text-center py-0" name="player2_score" id="player2_score"><?php echo e($game->player2_score); ?></textarea>
        </div>
        <div class="control">
            <button class="button is-link flex-1 px-4 py-2 m-2 font-bold text-white bg-blue-500 rounded-full mr-l hover:bg-blue-700" type="submit">Submit</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\ScoreTracker\resources\views/edit.blade.php ENDPATH**/ ?>
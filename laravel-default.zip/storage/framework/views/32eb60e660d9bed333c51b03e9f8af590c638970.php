<?php $__env->startSection('content'); ?>
<div class="container flex justify-center mx-auto">
    <div class="shadow-xl px-12 py-8 bg-gray-200 border border-gray-300 rounded-xl">
        <div class="col-md-8">
            <form action="" method="post" action="<?php echo e(route('contact.store')); ?>">

                <?php echo csrf_field(); ?>

                <div class="mb-4 text-lg font-bold ">
                    <label>Name</label>
                    <input type="text" class="w-full p-2 border border-gray-400 <?php echo e($errors->has('name') ? 'error' : ''); ?>" name="name" id="name">

                    <!-- Error -->
                    <?php if($errors->has('name')): ?>
                    <div class="text-red-500 text-xs">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="mb-4 text-lg font-bold">
                    <label>Email</label>
                    <input type="email" class="w-full p-2 border border-gray-400 <?php echo e($errors->has('email') ? 'error' : ''); ?>" name="email" id="email">

                    <?php if($errors->has('email')): ?>
                    <div class="text-red-500 text-xs">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="mb-4 text-lg font-bold">
                    <label>Subject</label>
                    <input type="text" class="w-full p-2 border border-gray-400 <?php echo e($errors->has('subject') ? 'error' : ''); ?>" name="subject"
                        id="subject">

                    <?php if($errors->has('subject')): ?>
                    <div class="text-red-500 text-xs">
                        <?php echo e($errors->first('subject')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="mb-4 text-lg font-bold">
                    <label>Message</label>
                    <textarea class="w-full p-2 border border-gray-400 <?php echo e($errors->has('message') ? 'error' : ''); ?>" name="message" id="message"
                        rows="4"></textarea>

                    <?php if($errors->has('message')): ?>
                    <div class="text-red-500 text-xs">
                        <?php echo e($errors->first('message')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <input type="submit" name="send" value="Submit" class="px-4 py-2 mr-2 text-white bg-blue-400 rounded hover:bg-blue-500">
            </form>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/ScoreTracker/resources/views/contact.blade.php ENDPATH**/ ?>
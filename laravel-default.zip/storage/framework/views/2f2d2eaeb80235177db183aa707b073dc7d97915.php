<div class="border-8 border-gray-300 py-3 px-6 m-2">
    <div class="w-auto ">
        <label class="flex-1 block mb-2 text-xs font-bold tracking-wide text-indigo-400 uppercase" for="grid-first-name">
        Description of Game
        </label>
        <textarea class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none" name='description' rows="4"></textarea>
    </div>
</div>
<?php /**PATH C:\work\ScoreTracker\resources\views/description.blade.php ENDPATH**/ ?>
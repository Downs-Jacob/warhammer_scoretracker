    <?php $__env->startSection('content'); ?>
    <div class="container flex justify-center mx-auto">
        <div class="shadow-xl px-12 py-8 bg-gray-200 border border-gray-300 rounded-xl">
            <div class="col-md-8">

                    <div class="mb-2 text-lg font-bold"><?php echo e(__('Register')); ?></div>
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class='mb-2'>
                                <label class="block mb-2 text-xs font-bold uppercase text-grey-700" for="username">
                                    Username
                                </label>
                                <input class="w-full p-2 border border-gray-400" type="text" name="username" id="username" required>

                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                            <div class='mb-2'>
                                <label class="block mb-2 text-xs font-bold uppercase text-grey-700" for="name">
                                    name
                                </label>
                                <input class="w-full p-2 border border-gray-400" type="text" name="name" id="name" required>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class='mb-2'>
                                <label class="block mb-2 text-xs font-bold uppercase text-grey-700" for="email">
                                    Email
                                </label>
                                <input class="w-full p-2 border border-gray-400" type="text" name="email" id="email"
                                    autocomplete="email" required>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class='mb-2'>
                                <label class="block mb-2 text-xs font-bold uppercase text-grey-700" for="password">
                                    Password
                                </label>
                                <input class="w-full p-2 border border-gray-400" type="password" name="password" id="password"
                                    autocomplete="current-password" required>

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-xs text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class='mb-2'>
                                <label class="block mb-2 text-xs font-bold uppercase text-grey-700" for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>
                                <input class="w-full p-2 border border-gray-400" type="password" name="password_confirmation" id="password_confirmation" reqired-autocomplete="new-password">
                            </div>

                            <div class="mb-0 form-group row">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="px-6 py-4 text-sm text-white uppercase bg-blue-400 rounded">
                                        <?php echo e(__('Register')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/ScoreTracker/resources/views/auth/register.blade.php ENDPATH**/ ?>